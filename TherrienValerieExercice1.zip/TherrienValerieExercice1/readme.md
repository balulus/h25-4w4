# Exercice #1
## Concevoir une page d'accueil en HTML / CSS à partir d'une maquette
### Auteur: Valerie Therrien
La réalisation de ce prototype représente une première étape pour la conception d'un thème Worpress.
#### Github-page : https://github.com/balulus/h25-4w4/tree/exercice-1